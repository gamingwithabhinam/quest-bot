import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
import logger as _L

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

def run(cfg: dict):
    quest_ids    = [q for q in cfg.get("quest_ids", []) if q and q.strip()]
    threads      = int(cfg.get("threads", 5))
    enroll_first = cfg.get("enroll_first", True)

    from enroll import run as enroll_run
    from bot    import run as bot_run

    if enroll_first:
        _L.info("", "Enroll phase starting...")
        discovered = enroll_run(quest_ids, max_threads=threads)
        if not quest_ids and discovered:
            quest_ids = discovered

    bot_run(quest_ids=quest_ids, max_threads=threads)
    return quest_ids
