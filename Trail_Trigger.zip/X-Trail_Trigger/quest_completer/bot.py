import os
import sys
import time
import threading
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
import logger as _L

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
from client        import DiscordREST, GatewayClient
from quest_manager import QuestManager

TOKENS_FILE  = os.path.join(ROOT, "tokens.txt")
SUCCESS_FILE = os.path.join(ROOT, "success.txt")
FAILED_FILE  = os.path.join(ROOT, "failed.txt")

_file_lock    = threading.Lock()
_counter_lock = threading.Lock()

def _save_success(token):
    with _file_lock:
        try:
            with open(SUCCESS_FILE, "a", encoding="utf-8") as f:
                f.write(token + "\n")
        except:
            pass

def _save_failed(token, reason):
    with _file_lock:
        try:
            with open(FAILED_FILE, "a", encoding="utf-8") as f:
                f.write(f"{token} | quest_completer | {reason}\n")
        except:
            pass

def _parse_token(line):
    line = line.strip()
    if not line or line.startswith("#"):
        return ""
    if line.count(":") >= 2:
        return ":".join(line.split(":")[2:]).strip()
    return line

def _load_tokens():
    try:
        with open(TOKENS_FILE, encoding="utf-8") as f:
            return list(dict.fromkeys(
                t for t in [_parse_token(l) for l in f]
                if t and len(t) > 50
            ))
    except:
        return []

def _loginAccount(token, index):
    short = token[:20] + "..."
    rest  = DiscordREST(token)
    gw    = GatewayClient(token)
    try:
        data     = gw.connect(timeout=30)
        username = data.get("user", {}).get("username", "?")
        _L.success("", f"Login OK -> {short}")
        return {
            "rest":       rest,
            "gw":         gw,
            "accountId":  f"# {index+1}",
            "username":   username,
            "rawToken":   token,
        }
    except Exception as e:
        _L.error("", f"Login failed → {short}: {e}")
        gw.destroy()
        return None

def _processQuests(account, questIds, counters):
    short = account["rawToken"][:20] + "..."
    rest  = account["rest"]
    accId = account["accountId"]

    try:
        try:
            resp = rest.get("/quests/@me")
        except Exception as e:
            _L.error("", f"fetchQuests failed → {short}: {e}")
            _save_failed(account["rawToken"], f"fetchQuests: {e}")
            with _counter_lock:
                counters["failed"] += 1
            return

        qm = QuestManager.fromResponse(rest, resp)
        valid = qm.filterQuestsValid(questIds)

        alreadyDone = [
            q for q in qm.list()
            if q.isCompleted() and not q.hasClaimedRewards()
            and (len(questIds) == 0 or q.id in questIds)
        ]
        if alreadyDone:
            names = ", ".join(q.quest_name() for q in alreadyDone)
            _L.warning("", f"Already completed → {short} ({names})")

        alreadyClaimed = [
            q for q in qm.list()
            if q.hasClaimedRewards()
            and (len(questIds) == 0 or q.id in questIds)
        ]
        if alreadyClaimed:
            names = ", ".join(q.quest_name() for q in alreadyClaimed)
            _L.warning("", f"Already claimed → {short} ({names})")
            with _counter_lock:
                counters["success"] += 1
            _save_success(account["rawToken"])
            return

        if not valid:
            _L.error("", f"No valid quests → {short}")
            with _counter_lock:
                counters["failed"] += 1
            _save_failed(account["rawToken"], "no_valid_quests")
            return

        completed_one = False
        for q in valid:
            try:
                qm.doingQuest(q, accId)
                completed_one = True
                break
            except Exception as e:
                status = getattr(e, "status", 0)
                if status == 404:
                    continue
                _L.error("", f"Quest error → {short}: {e}")
                break

        with _counter_lock:
            counters["success"] += 1
        _save_success(account["rawToken"])

    except Exception as e:
        _L.error("", f"Failed → {short}: {e}")
        _L.error("", traceback.format_exc())
        with _counter_lock:
            counters["failed"] += 1
        _save_failed(account["rawToken"], str(e))
    finally:
        try:
            account["gw"].destroy()
        except:
            pass

def run(quest_ids=None, max_threads=5):
    questIds = quest_ids or []

    tokens = _load_tokens()
    if not tokens:
        _L.error("", "No valid tokens found")
        return

    _L.info("", f"Quest Completer → {len(tokens)} tokens | threads: {max_threads}")
    counters      = {"success": 0, "failed": 0}
    totalBatches  = -(-len(tokens) // max_threads)

    for b in range(totalBatches):
        start = b * max_threads
        end   = min(start + max_threads, len(tokens))
        batch = tokens[start:end]

        accounts = []
        with ThreadPoolExecutor(max_workers=max(1, len(batch))) as ex:
            futs = {ex.submit(_loginAccount, t, start+i): t for i, t in enumerate(batch)}
            for f in as_completed(futs):
                try:
                    acc = f.result()
                    if acc:
                        accounts.append(acc)
                except Exception as e:
                    _L.error("", f"Login thread error: {e}")

        if not accounts:
            _L.error("", "No accounts logged in - skipping batch")
            continue

        with ThreadPoolExecutor(max_workers=max(1, len(accounts))) as ex:
            futs = [ex.submit(_processQuests, acc, questIds, counters) for acc in accounts]
            for f in as_completed(futs):
                try:
                    f.result()
                except Exception as e:
                    _L.error("", f"Process thread error: {e}")

    _L.info("", f"Completer done → ✓ {counters['success']}  ✗ {counters['failed']}")
