import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
import logger as _L

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
from client import DiscordREST, GatewayClient

TOKENS_FILE = os.path.join(ROOT, "tokens.txt")

def _parse_token(line):
    line = line.strip()
    if not line or line.startswith("#"):
        return ""
    if line.count(":") >= 2:
        return ":".join(line.split(":")[2:]).strip()
    return line

def _load_tokens():
    try:
        with open(TOKENS_FILE, encoding="utf-8") as f:
            return list(dict.fromkeys(
                t for t in [_parse_token(l) for l in f]
                if t and len(t) > 50
            ))
    except:
        return []

def _enrollToken(token, index, questIds):
    rest  = DiscordREST(token)
    gw    = GatewayClient(token)

    try:
        gw.connect(timeout=30)
    except:
        pass
    finally:
        gw.destroy()

    for questId in questIds:
        try:
            try:
                rest.get(f"/quests/{questId}")
            except Exception as e:
                if getattr(e, "status", 0) == 404:
                    continue

            time.sleep(0.3)

            rest.post(f"/quests/{questId}/enroll", body={
                "location": 11, "is_targeted": False, "metadata_raw": None
            })

        except Exception as e:
            msg = str(e)
            if "already" not in msg.lower() and getattr(e, "status", 0) != 400:
                _L.warning("", f"Enroll failed → {questId} (# {index+1}): {msg}")

def _discover_quest_ids(token):
    from datetime import datetime, timezone
    rest = DiscordREST(token)
    try:
        resp = rest.get("/quests/@me")
    except Exception as e:
        _L.warning("", f"Auto-discover fetch failed: {e}")
        return []

    ids = []
    for q in resp.get("quests", []):
        cfg      = q.get("config", {})
        us       = q.get("user_status") or {}
        features = cfg.get("features", [])
        tasks    = cfg.get("task_config", {}).get("tasks", {})

        try:
            exp = cfg.get("expires_at", "")
            if exp:
                dt = datetime.fromisoformat(exp.replace("Z", "+00:00"))
                if datetime.now(timezone.utc) > dt:
                    continue
        except:
            pass

        if us.get("completed_at"):
            continue

        VIDEO_TASKS = {"WATCH_VIDEO", "WATCH_VIDEO_ON_MOBILE"}
        has_video   = any(k in VIDEO_TASKS and tasks.get(k) is not None for k in tasks)
        is_feat15   = 15 in features

        if has_video or is_feat15:
            ids.append(q["id"])

    return ids

def run(questIds, max_threads=5):
    if questIds is None:
        questIds = []

    tokens = _load_tokens()
    if not tokens:
        return []

    if not questIds:
        _L.info("", "No quest_ids set - auto-discovering video quests...")
        questIds = _discover_quest_ids(tokens[0])
        if not questIds:
            _L.warning("", "No active video quests found - skipping enroll")
            return []

    _L.info("", f"Enrolling {len(tokens)} tokens")

    with ThreadPoolExecutor(max_workers=max(1, max_threads)) as ex:
        futs = [ex.submit(_enrollToken, t, i, questIds) for i, t in enumerate(tokens)]
        for f in as_completed(futs):
            try:
                f.result()
            except:
                pass

    _L.success("", "Enroll done")
    return questIds
