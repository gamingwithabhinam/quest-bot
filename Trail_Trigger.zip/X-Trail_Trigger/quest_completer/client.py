import json, time, random, base64, asyncio, threading
import websocket
import tls_client
import uuid as _uuid

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) discord/1.0.9215 Chrome/138.0.7204.251 "
    "Electron/37.6.0 Safari/537.36"
)

PROPERTIES = {
    "os": "Windows",
    "browser": "Discord Client",
    "release_channel": "stable",
    "client_version": "1.0.9215",
    "os_version": "10.0.19045",
    "os_arch": "x64",
    "app_arch": "x64",
    "system_locale": "en-US",
    "has_client_mods": False,
    "client_launch_id": str(_uuid.uuid4()),
    "browser_user_agent": USER_AGENT,
    "browser_version": "37.6.0",
    "os_sdk_version": "19045",
    "client_build_number": 471091,
    "native_build_number": 72186,
    "client_event_source": None,
    "launch_signature": str(_uuid.uuid4()),
    "client_heartbeat_session_id": str(_uuid.uuid4()),
    "client_app_state": "focused",
}

XSUP = base64.b64encode(json.dumps(PROPERTIES, separators=(',', ':')).encode()).decode()

API_BASE = "https://discord.com/api/v10"

OP_DISPATCH   = 0
OP_HEARTBEAT  = 1
OP_IDENTIFY   = 2
OP_HELLO      = 10
OP_HB_ACK     = 11
OP_INV_SESS   = 9

GATEWAY_URL = "wss://gateway.discord.gg/?v=10&encoding=json"

class DiscordREST:
    def __init__(self, token: str):
        self.token = token
        self._session = tls_client.Session(
            client_identifier="chrome_120",
            random_tls_extension_order=True
        )

    def _headers(self, extra: dict = None) -> dict:
        h = {
            "Authorization":       self.token,
            "Content-Type":        "application/json",
            "User-Agent":          USER_AGENT,
            "Accept":              "*/*",
            "Accept-Language":     "en-US",
            "Origin":              "https://discord.com",
            "Referer":             "https://discord.com/channels/@me",
            "Pragma":              "no-cache",
            "Cache-Control":       "no-cache",
            "Priority":            "u=1, i",
            "sec-ch-ua":           '"Not)A;Brand";v="8", "Chromium";v="138"',
            "sec-ch-ua-mobile":    "?0",
            "sec-ch-ua-platform":  '"Windows"',
            "sec-fetch-dest":      "empty",
            "sec-fetch-mode":      "cors",
            "sec-fetch-site":      "same-origin",
            "x-debug-options":     "bugReporterEnabled",
            "x-discord-locale":    "en-US",
            "x-discord-timezone":  "Asia/Kolkata",
            "x-super-properties":  XSUP,
        }
        if extra:
            h.update(extra)
        return h

    def _request(self, method: str, path: str, body=None, params=None, retries=3, delay=0.5):
        url = API_BASE + path
        for attempt in range(retries):
            try:
                if method == "GET":
                    r = self._session.get(url, headers=self._headers(), params=params)
                elif method == "POST":
                    r = self._session.post(url, headers=self._headers(), json=body)
                elif method == "PATCH":
                    r = self._session.patch(url, headers=self._headers(), json=body)
                else:
                    raise ValueError(f"Unknown method: {method}")

                sc = r.status_code

                if sc == 429:
                    try: ra = r.json().get("retry_after", 2)
                    except: ra = 2
                    time.sleep(float(ra))
                    continue

                if sc in (500, 502, 503, 504):
                    time.sleep(delay * (attempt + 1))
                    continue

                if sc == 204:
                    return {}

                if sc in (200, 201):
                    try:    return r.json()
                    except: return {}

                try:    rj = r.json()
                except: rj = {}
                err = Exception(rj.get("message", f"HTTP {sc}"))
                err.status = sc
                err.body   = rj
                raise err

            except Exception as e:
                if hasattr(e, 'status'):
                    raise
                if attempt < retries - 1:
                    time.sleep(delay)
                    continue
                raise
        raise Exception("Max retries exceeded")

    def get(self, path: str, params=None):
        return self._request("GET", path, params=params)

    def post(self, path: str, body=None):
        return self._request("POST", path, body=body)

    def patch(self, path: str, body=None):
        return self._request("PATCH", path, body=body)

class GatewayClient:
    def __init__(self, token: str):
        self.token       = token
        self.ws          = None
        self._seq        = None
        self._hb_timer   = None
        self._hb_interval= None
        self._connected  = threading.Event()
        self._ready_data = None
        self._error      = None
        self._closed     = False
        self._thread     = None

    def connect(self, timeout=30) -> dict:
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        ok = self._connected.wait(timeout=timeout)
        if not ok:
            self.destroy()
            raise TimeoutError("Gateway connect timeout")
        if self._error:
            raise self._error
        return self._ready_data

    def destroy(self):
        self._closed = True
        if self._hb_timer:
            self._hb_timer.cancel()
            self._hb_timer = None
        if self.ws:
            try: self.ws.close()
            except: pass

    def _run(self):
        try:
            headers = {
                "User-Agent":    USER_AGENT,
                "Accept-Language": "en-US",
                "Cache-Control": "no-cache",
                "Pragma":        "no-cache",
            }
            self.ws = websocket.WebSocketApp(
                GATEWAY_URL,
                header=[f"{k}: {v}" for k, v in headers.items()],
                on_message=self._on_message,
                on_error=self._on_error,
                on_close=self._on_close,
            )
            self.ws.run_forever(ping_interval=0, ping_timeout=None)
        except Exception as e:
            self._error = e
            self._connected.set()

    def _on_message(self, ws, raw):
        try:
            payload = json.loads(raw)
        except: return

        op = payload.get("op")
        d  = payload.get("d")
        s  = payload.get("s")
        t  = payload.get("t")

        if s is not None:
            self._seq = s

        if op == OP_HELLO:
            interval = d["heartbeat_interval"] / 1000.0
            self._hb_interval = interval
            jitter = random.random() * interval
            self._hb_timer = threading.Timer(jitter, self._heartbeat_loop)
            self._hb_timer.daemon = True
            self._hb_timer.start()
            self._send_identify()

        elif op == OP_HB_ACK:
            pass

        elif op == OP_DISPATCH and t == "READY":
            self._ready_data = d
            self._connected.set()

        elif op == OP_INV_SESS:
            self._error = Exception("Invalid Session")
            self._connected.set()
            self.destroy()

    def _on_error(self, ws, error):
        self._error = Exception(str(error))
        self._connected.set()

    def _on_close(self, ws, code, msg):
        if not self._connected.is_set():
            self._error = Exception(f"WS closed {code}")
            self._connected.set()

    def _heartbeat_loop(self):
        if self._closed: return
        self._send_heartbeat()
        if self._hb_interval:
            self._hb_timer = threading.Timer(self._hb_interval, self._heartbeat_loop)
            self._hb_timer.daemon = True
            self._hb_timer.start()

    def _send_heartbeat(self):
        try:
            if self.ws:
                self.ws.send(json.dumps({"op": OP_HEARTBEAT, "d": self._seq}))
        except: pass

    def _send_identify(self):
        payload = {
            "op": OP_IDENTIFY,
            "d": {
                "token": self.token,
                "capabilities": 30717,
                "properties": {
                    "os": "Windows",
                    "browser": "Discord Client",
                    "release_channel": "stable",
                    "client_version": "1.0.9215",
                    "os_version": "10.0.19045",
                    "os_arch": "x64",
                    "app_arch": "x64",
                    "system_locale": "en-US",
                    "has_client_mods": False,
                    "browser_user_agent": USER_AGENT,
                    "browser_version": "37.6.0",
                    "os_sdk_version": "19045",
                    "client_build_number": 471091,
                    "native_build_number": 72186,
                    "client_event_source": None,
                },
                "presence": {"status": "online", "since": 0, "activities": [], "afk": False},
                "compress": False,
                "client_state": {"guild_versions": {}},
            }
        }
        try:
            if self.ws:
                self.ws.send(json.dumps(payload))
        except: pass
