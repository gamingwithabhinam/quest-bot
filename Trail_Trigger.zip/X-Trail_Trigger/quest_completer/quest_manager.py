import time
import random
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
import logger as _L

def _sleep(s):
    time.sleep(s)

def _retry(fn, retries=3, delay=0.5):
    last = None
    for i in range(retries):
        try:
            return fn()
        except Exception as e:
            last   = e
            status = getattr(e, "status", 0)
            body   = getattr(e, "body",   {}) or {}
            if status == 429 or status >= 500:
                ra = body.get("retry_after", delay * (i + 1))
                _sleep(float(ra))
                continue
            raise
    raise last

class Quest:
    def __init__(self, data: dict):
        self._d = data

    @classmethod
    def create(cls, data):
        return cls(data)

    @property
    def id(self):
        return self._d["id"]

    @property
    def config(self):
        return self._d["config"]

    @property
    def user_status(self):
        return self._d.get("user_status") or {}

    def quest_name(self):
        return self.config.get("messages", {}).get("quest_name", "?")

    def game_title(self):
        return self.config.get("messages", {}).get("game_title", "")

    def app_name(self):
        return self.config.get("application", {}).get("name", "")

    def app_id(self):
        return self.config.get("application", {}).get("id", "")

    def is_expired(self):
        from datetime import datetime, timezone
        try:
            exp = self.config["expires_at"]
            dt  = datetime.fromisoformat(exp.replace("Z", "+00:00"))
            return datetime.now(timezone.utc) > dt
        except:
            return False

    def isCompleted(self):
        return bool(self.user_status.get("completed_at"))

    def isEnrolledQuest(self):
        return bool(self.user_status.get("enrolled_at"))

    def hasClaimedRewards(self):
        return bool(self.user_status.get("claimed_at"))

    def updateUserStatus(self, s):
        if s:
            self._d["user_status"] = s

    def task_info(self):
        tasks = self.config.get("task_config", {}).get("tasks", {})
        for name in ["WATCH_VIDEO", "PLAY_ON_DESKTOP", "STREAM_ON_DESKTOP",
                     "PLAY_ACTIVITY", "WATCH_VIDEO_ON_MOBILE", "PLAY_ON_MOBILE",
                     "LINK_ACCOUNT", "PLAY_GAME", "WATCH_STREAM"]:
            if name in tasks and tasks[name] is not None:
                target = tasks[name].get("target", 0)
                done   = self.user_status.get("progress", {}).get(name, {}).get("value", 0)
                return name, target, done
        for name, val in tasks.items():
            if val is not None:
                target = val.get("target", 0) if isinstance(val, dict) else 0
                done   = self.user_status.get("progress", {}).get(name, {}).get("value", 0)
                import logger as _L2
                _L2.warning("", f"Unknown task type '{name}' — attempting generic handling | Quest: {self.quest_name()}")
                return name, target, done
        return None, 0, 0

class QuestManager:
    def __init__(self, rest, quests):
        self._rest   = rest
        self._quests = {q.id: q for q in quests}

    @classmethod
    def fromResponse(cls, rest, response: dict):
        return cls(rest, [Quest.create(q) for q in response.get("quests", [])])

    def list(self):
        return list(self._quests.values())

    def get(self, qid):
        return self._quests.get(qid)

    def filterQuestsValid(self, targetQuestIds=None):
        excludedNames = ['DESTINY', 'DESTINY 2']
        exclusionId   = '1412491570820812933'
        result = []
        for q in self.list():
            if q.isCompleted() or q.is_expired():
                continue
            if targetQuestIds and len(targetQuestIds) > 0:
                if q.id in targetQuestIds:
                    result.append(q)
                continue
            if q.id == exclusionId:
                continue
            gt = q.game_title().upper()
            qn = q.quest_name().upper()
            if any(n in gt or n in qn for n in excludedNames):
                continue
            features  = q.config.get("features", [])
            tasks     = q.config.get("task_config", {}).get("tasks", {})
            VIDEO_TASKS = {"WATCH_VIDEO", "WATCH_VIDEO_ON_MOBILE"}
            has_video = any(k in VIDEO_TASKS and tasks[k] is not None for k in tasks)
            is_feat15 = 15 in features
            if has_video or is_feat15:
                result.append(q)
        return result

    def acceptQuest(self, quest: Quest):
        def _do():
            r = self._rest.post(f"/quests/{quest.id}/enroll",
                                body={"location": 11, "is_targeted": False, "metadata_raw": None})
            quest.updateUserStatus(r)
            return r
        return _retry(_do)

    def doingQuest(self, quest: Quest, accountIdentifier: str):
        questName = quest.quest_name()

        if not quest.isEnrolledQuest():
            try:
                self.acceptQuest(quest)
                _sleep(1.0)
            except Exception as e:
                _L.error("", f"Enroll failed | Quest: {questName} | Account: {accountIdentifier}")
                return

        try:
            us = _retry(lambda: self._rest.get(f"/quests/{quest.id}/user-status"))
            if us:
                quest.updateUserStatus(us)
        except:
            pass

        task_name, secondsNeeded, secondsDone = quest.task_info()

        if not task_name:
            features = quest.config.get("features", [])
            if 15 in features:
                task_name     = "WATCH_VIDEO"
                secondsDone   = 0
                secondsNeeded = 0
                for k, v in quest.user_status.get("progress", {}).items():
                    if isinstance(v, dict):
                        secondsNeeded = v.get("target", 0)
                        secondsDone   = v.get("value", 0)
                        task_name     = k if k in ("WATCH_VIDEO", "WATCH_VIDEO_ON_MOBILE") else "WATCH_VIDEO"
                        break
                if not secondsNeeded:
                    secondsNeeded = 900
            else:
                raw_tasks = quest.config.get("task_config", {}).get("tasks", {})
                _L.warning("", f"No task found | Quest: {questName} | Raw tasks: {list(raw_tasks.keys())}")
                return

        if task_name in ("WATCH_VIDEO", "WATCH_VIDEO_ON_MOBILE"):
            STEP = 2

            def _build_ts(start, end):
                ts_list, cursor = [], start
                while cursor < end:
                    cursor = min(cursor + STEP, end)
                    ts_list.append(round((cursor + random.random() * 0.1) * 10) / 10)
                if ts_list and ts_list[-1] != float(end):
                    ts_list.append(float(end))
                return ts_list

            def _reconnect_gateway():
                try:
                    from client import GatewayClient
                    gw = GatewayClient(self._rest.token)
                    gw.connect(timeout=20)
                    gw.destroy()
                except:
                    pass
                _sleep(1.5)

            try:
                _retry(lambda: self._rest.post(
                    f"/quests/{quest.id}/video-progress",
                    body={"timestamp": 1.0}
                ))
            except Exception as e:
                if getattr(e, "status", 0) == 404:
                    raise

            completed    = False
            max_retries  = 60
            last_good_ts = secondsDone

            for attempt in range(max_retries):
                if completed:
                    break

                try:
                    fresh = _retry(lambda: self._rest.get(f"/quests/{quest.id}/user-status"))
                    if fresh:
                        quest.updateUserStatus(fresh)
                        if fresh.get("completed_at"):
                            completed = True
                            break
                        sv = fresh.get("progress", {})
                        for k in ("WATCH_VIDEO", "WATCH_VIDEO_ON_MOBILE"):
                            v = sv.get(k, {}).get("value", 0)
                            if v:
                                last_good_ts = max(last_good_ts, v)
                except:
                    pass

                if completed:
                    break

                ts_list = _build_ts(last_good_ts, secondsNeeded)

                got_400 = False
                for ts in ts_list:
                    if completed:
                        break
                    try:
                        res = _retry(lambda ts=ts: self._rest.post(
                            f"/quests/{quest.id}/video-progress",
                            body={"timestamp": ts}
                        ))
                        if res:
                            quest.updateUserStatus(res)
                            last_good_ts = ts
                            if res.get("completed_at"):
                                completed = True
                                break
                    except Exception as e:
                        status = getattr(e, "status", 0)
                        if status == 404:
                            raise
                        elif status == 400:
                            got_400 = True
                            break
                        elif status != 429 and status < 500:
                            _L.warning("", f"ts {ts} rejected ({status}) | Quest: {questName}")
                    _sleep(0.15 + random.uniform(0, 0.1))

                if completed:
                    break

                if got_400:
                    _reconnect_gateway()
                else:
                    for _ in range(5):
                        _sleep(1)
                        try:
                            st = _retry(lambda: self._rest.get(f"/quests/{quest.id}/user-status"))
                            if st and st.get("completed_at"):
                                quest.updateUserStatus(st)
                                completed = True
                                break
                        except:
                            pass
                    if not completed and attempt < max_retries - 1:
                        _reconnect_gateway()

            if completed or quest.isCompleted():
                _L.success("", f"Quest done | Quest: {questName} | Account: {accountIdentifier}")
            else:
                _L.error("", f"Quest incomplete | Quest: {questName} | Account: {accountIdentifier}")

        elif task_name == "PLAY_ON_DESKTOP":
            app_id = quest.app_id()
            while not quest.isCompleted() and not quest.is_expired():
                _, _, done = quest.task_info()
                if done >= secondsNeeded:
                    break
                try:
                    res = _retry(lambda: self._rest.post(
                        f"/quests/{quest.id}/heartbeat",
                        body={"application_id": app_id, "terminal": False}
                    ))
                    if res:
                        quest.updateUserStatus(res)
                except:
                    break
                _sleep(30.0)

            try:
                res = _retry(lambda: self._rest.post(
                    f"/quests/{quest.id}/heartbeat",
                    body={"application_id": app_id, "terminal": True}
                ))
                if res:
                    quest.updateUserStatus(res)
            except:
                pass

            if quest.isCompleted():
                _L.success("", f"Quest done | Quest: {questName} | Account: {accountIdentifier}")
            else:
                _L.error("", f"Quest incomplete | Quest: {questName} | Account: {accountIdentifier}")

        else:
            _L.warning("", f"Unsupported task type: '{task_name}' (target={secondsNeeded}) | Quest: {questName}")
