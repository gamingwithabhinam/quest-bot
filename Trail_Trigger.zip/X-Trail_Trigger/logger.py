import threading
from datetime import datetime

_print_lock = threading.Lock()

R    = "\x1b[0m";  B = "\x1b[1m";  D = "\x1b[2m"
bGRN = "\x1b[92m"; bRED = "\x1b[91m"; bYEL = "\x1b[93m"
bCYN = "\x1b[96m"; bWHT = "\x1b[97m"; bMAG = "\x1b[95m"
GRN  = "\x1b[32m"; RED  = "\x1b[31m"; YEL  = "\x1b[33m"
CYN  = "\x1b[36m"; WHT  = "\x1b[37m"; ORG  = "\x1b[38;5;208m"
BGGRN = "\x1b[42m"; BGRED = "\x1b[41m"

def print_banner():
    import sys
    sys.stdout.write(bCYN)
    print(r"""
   ██╗  ██╗███╗   ███╗ █████╗ ██████╗ ██╗  ██╗███████╗████████╗
   ╚██╗██╔╝████╗ ████║██╔══██╗██╔══██╗██║ ██╔╝██╔════╝╚══██╔══╝
    ╚███╔╝ ██╔████╔██║███████║██████╔╝█████╔╝ █████╗     ██║   
    ██╔██╗ ██║╚██╔╝██║██╔══██║██╔══██╗██╔═██╗ ██╔══╝     ██║   
   ██╔╝ ██╗██║ ╚═╝ ██║██║  ██║██║  ██║██║  ██╗███████╗   ██║   
   ╚═╝  ╚═╝╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝   ╚═╝   
    """)
    sys.stdout.write(R)
    print(f"\n        {B}{bGRN}developer x-market{R}\n")

def _ts():
    return f"{D}[{WHT}{datetime.now().strftime('%H:%M:%S')}{D}]{R}"

def _log(prefix_col, prefix, msg_col, msg, detail=None):
    parts = [f"{_ts()}", f"  {prefix_col}{B}{prefix}{R}", f"  {msg_col}{msg}{R}"]
    if detail:
        parts.append(f"  {D}{detail}{R}")
    with _print_lock:
        print("".join(parts))

def success(token, message, detail=None): 
    _log(bGRN, "(+)", WHT, message, detail)
def error(token, message, detail=None):   
    _log(bRED, "(-)", WHT, message, detail)
def warning(token, message, detail=None): 
    _log(ORG,  "(*)", WHT, message, detail)
def info(token, message, detail=None):    
    _log(bCYN, "(i)", WHT, message, detail)
def captcha(token, message, detail=None): 
    _log(bMAG, "(#)", bMAG, message, detail)

def login_ok(token_short):
    ts = _ts()
    with _print_lock:
        print(f"{ts}  {BGGRN}\x1b[30m{B} (+) LOGIN {R}  {bGRN}{token_short}{R}")

def login_fail(token_short, reason=""):
    ts = _ts()
    with _print_lock:
        print(f"{ts}  {BGRED}{bWHT}{B} (-) FAIL {R}  {RED}{token_short}{R}  {D}{reason}{R}")

def code(token, reward_code):
    _log(bGRN, "($)", WHT, f"Code {B}{bGRN}{reward_code}{R}")

def divider():
    with _print_lock:
        print(f"  {D}{'·' * 48}{R}")

def section(title):
    with _print_lock:
        print(f"\n  {B}{bCYN}◇ {title}{R}\n")

def config_box(rows):
    with _print_lock:
        print(f"  {D}╭{'─' * 44}╮{R}")
        for key, val in rows:
            print(f"  {D}│{R}  {CYN}{key:<14}{R} {bWHT}{str(val):<28}{R} {D}│{R}")
        print(f"  {D}╰{'─' * 44}╯{R}")

def summary(title, total, success_count, failed_count):
    with _print_lock:
        print(f"\n  {B}{bCYN}{title}{R}")
        print(f"  {bGRN}(+) Success{R}  {bWHT}{success_count}{R}  {D}|{R}  {bRED}(-) Failed{R}  {bWHT}{failed_count}{R}  {D}|{R}  {WHT}Total{R}  {bWHT}{total}{R}\n")
