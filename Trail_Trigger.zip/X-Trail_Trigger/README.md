# x-market

A powerful Discord automation tool for managing multiple accounts, completing quests, and automating server interactions.

**Credits: x-market Team**

---

## Features

- **Multi-Account Management** - Handle multiple Discord accounts simultaneously
- **OAuth2 Integration** - Automated OAuth2 authorization flow
- **Quest Completer** - Automatically enroll and complete Discord quests
- **Voice Channel Automation** - Join voice channels with options for mute, video, and go-live
- **Chat Automation** - Smart conversation engine that mimics human-like chat behavior
- **Server Joining** - Bulk join servers via invite codes or OAuth2
- **Typing Indicators** - Realistic typing simulation before sending messages

---

## Requirements

- Python 3.8+
- Discord Bot Token
- Discord OAuth2 Application (Client ID & Client Secret)

### Python Dependencies

```bash
pip install aiohttp websockets colorama requests tls-client
```

---

## Setup

### 1. Configuration

Edit `config.json` with your Discord application credentials:

```json
{
    "bot_token": "YOUR_BOT_TOKEN",
    "client_id": "YOUR_CLIENT_ID",
    "client_secret": "YOUR_CLIENT_SECRET",
    "redirect_uri": "http://localhost:8080",
    "use_proxy": false,
    "max_workers": 10,
    "quest_completer": {
        "enabled": true,
        "enroll_first": true,
        "quest_ids": [],
        "threads": 10
    }
}
```

**How to get your credentials:**
1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Create a new application or select an existing one
3. Get your **Client ID** and **Client Secret** from OAuth2 section
4. Create a bot and copy the **Bot Token**
5. Add `http://localhost:8080` to OAuth2 Redirect URIs

### 2. Add Tokens

Create or edit `tokens.txt` and add your Discord account tokens (one per line):

```
token1
token2
token3
```

**Token format support:**
- Direct token: `MTAbcdef...`
- Email:Pass:Token: `email@example.com:password:MTAbcdef...`

---

## Usage

### Running the Tool

```bash
python main.py
```

### Main Menu Options

1. **Join Server**
   - Join a Discord server using invite code
   - Supports both OAuth2 and direct invite methods
   - Automatically checks membership status

2. **Quest Completer**
   - Automatically enroll in available quests
   - Complete quest requirements
   - Multi-threaded for fast processing

3. **Voice Channel Automation**
   - Join voice channels with multiple tokens
   - Options:
     - Self mute
     - Enable video
     - Start streaming (go-live)
   - Automatic reconnection on disconnects
   - Persistent presence maintenance

4. **Chat Automation**
   - Two modes:
     - **Smart Mode**: AI-powered conversation engine with natural replies
     - **Basic Mode**: Simple predefined messages
   - Realistic typing delays
   - Message threading and replies
   - Topic detection and context awareness

---

## Features in Detail

### Quest Completer

The quest completer module (`quest_completer/`) handles:
- Enrollment in Discord quests
- Automatic quest completion
- Progress tracking
- Multi-account support

### Smart Conversation Engine

Located in `conversation.py`, this generates human-like conversations:
- Dynamic topic detection (gaming, music, food, shows, etc.)
- Contextual replies and agreements/disagreements
- Natural language patterns with slang and emojis
- Conversation threading
- Mood-based responses

### Voice Automation

Advanced voice channel features:
- WebSocket-based connection
- Automatic heartbeat handling
- Reconnection on disconnects
- Stream/Go-live support
- Voice state monitoring

---

## Configuration Options

### config.json Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `bot_token` | Your Discord bot token | Required |
| `client_id` | OAuth2 Client ID | Required |
| `client_secret` | OAuth2 Client Secret | Required |
| `redirect_uri` | OAuth2 redirect URI | `http://localhost:8080` |
| `use_proxy` | Enable proxy support | `false` |
| `max_workers` | Thread pool size | `10` |
| `quest_completer.enabled` | Enable quest completion | `true` |
| `quest_completer.enroll_first` | Auto-enroll in quests | `true` |
| `quest_completer.quest_ids` | Specific quest IDs to complete | `[]` (all) |
| `quest_completer.threads` | Quest completer threads | `10` |

---

## Troubleshooting

### Common Issues

**Token Invalid / 4004 Error**
- Verify your tokens are valid and not locked
- Check if accounts have phone verification if required

**OAuth2 Failed**
- Verify Client ID, Client Secret, and Redirect URI match your application settings
- Ensure bot has proper permissions

**Connection Timeouts**
- Check your internet connection
- Reduce `max_workers` or `threads` values
- Enable `use_proxy` if you're rate limited

**Quest Completion Failed**
- Ensure accounts meet quest requirements
- Check if accounts are flagged or restricted
- Verify quest IDs are correct

---

## Safety & Rate Limiting

- The tool includes automatic rate limit handling
- Built-in delays prevent API abuse
- Exponential backoff on connection failures
- Respects Discord's WebSocket reconnection guidelines

---

## Legal Disclaimer

This tool is for educational purposes only. Using automation on Discord may violate their Terms of Service. Use at your own risk. The developers are not responsible for any accounts banned or actions taken by Discord.

---

## Credits

**Developer:** x-market

---

## Support

For issues, questions, or contributions, please contact the developer.

---

## License

This project is provided as-is with no warranty. Use responsibly.
